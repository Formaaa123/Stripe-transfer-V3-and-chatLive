<?php

@ini_set('display_errors', '0');
error_reporting(0);

/* 2. Fonction de log qui n’écrit qu’en développement */
if (!function_exists('dev_log')) {
    function dev_log(string $msg): void
    {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log($msg);
        }
    }
}


require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php' );
ob_start();
header( 'Content-Type: application/json; charset=utf-8' );

if ( ! class_exists( 'WooCommerce' ) ) wp_die( 'WooCommerce n\'est pas activé.' );
if ( ! class_exists( '\Stripe\Stripe' ) ) require_once __DIR__ . '/stripe/init.php';

\Stripe\Stripe::setApiKey( defined( 'STRIPE_SECRET_KEY' ) ? STRIPE_SECRET_KEY : '' );
if ( ! defined('STRIPE_SECRET_KEY') || empty(STRIPE_SECRET_KEY)) {
}


function get_stripe_payment_data($order_id) {
    if (!$order_id || !is_numeric($order_id)) return false;
    $data_file = ABSPATH . "/stripe/data/taxe_data_{$order_id}.json"; 
    if (file_exists($data_file)) {
        $json_data = json_decode(file_get_contents($data_file), true);
        error_log("Lecture fichier $data_file : " . print_r($json_data, true));
        if (
            is_array($json_data)
            && !empty($json_data['author_id'])
            && !empty($json_data['stripe_connect_id'])
        ) {
            return [
                'author_id'         => intval($json_data['author_id']),
                'stripe_connect_id' => sanitize_text_field($json_data['stripe_connect_id']),
                'tax_option'        => floatval($json_data['tax_option'] ?? 0),
                'taxe_sejour'       => intval($json_data['taxe_sejour'] ?? 0),
                'date_arrivee'      => $json_data['date_arrivee'] ?? '',
                'date_depart'       => $json_data['date_depart'] ?? '',
            ];
        }
    }
    return false;
}

if (isset($_GET['create_payment_intent'])) {
    $order_id = intval($_POST['order_id'] ?? 0);
    if (!$order_id) {
        wp_send_json_error(['error' => 'Order ID manquant.']);
    }

    // 1. Lecture prioritaire du fichier JSON TAXE_DATA
    $stripe_data = get_stripe_payment_data($order_id);
    $order = wc_get_order($order_id); // Toujours récupérer l'objet commande

    if ($stripe_data) {
        $author_id         = $stripe_data['author_id'];
        $stripe_connect_id = $stripe_data['stripe_connect_id'];
        $tax_option        = $stripe_data['tax_option'];
        $taxe_sejour       = $stripe_data['taxe_sejour'];
        $date_arrivee      = $stripe_data['date_arrivee'];
        $date_depart       = $stripe_data['date_depart'];
        error_log("✅ Données utilisées depuis TAXE_DATA JSON pour la commande #$order_id");
    } else {
        // 2. Fallback WooCommerce (session > métas > usermeta)
        if (!$order) wp_send_json_error(['error' => 'Commande introuvable.']);

        $session_key = 'stripe_extra_data_' . $order_id;
        $extra_data = (function_exists('WC') && WC()->session) ? WC()->session->get($session_key) : null;

        if (is_array($extra_data) && !empty($extra_data['author_id']) && !empty($extra_data['stripe_connect_id'])) {
            $author_id         = intval($extra_data['author_id']);
            $stripe_connect_id = sanitize_text_field($extra_data['stripe_connect_id']);
            $tax_option        = floatval($extra_data['tax_option'] ?? 0);
            $taxe_sejour       = intval($extra_data['taxe_sejour'] ?? 0);
            $date_arrivee      = $extra_data['date_arrivee'] ?? '';
            $date_depart       = $extra_data['date_depart'] ?? '';
            error_log("✅ Données utilisées depuis la session WooCommerce pour #$order_id");
        } else {
            $author_id         = intval($order->get_meta('author_id'));
            $stripe_connect_id = $order->get_meta('stripe_connect_id');
            $tax_option        = floatval($order->get_meta('tax_option'));
            $taxe_sejour       = intval($order->get_meta('taxe_calculation')); // en centimes
            $date_arrivee      = $order->get_meta('date_arrivee');
            $date_depart       = $order->get_meta('date_depart');

            // Fallback usermeta si certains champs manquants
            if ($author_id) {
                if (empty($stripe_connect_id)) $stripe_connect_id = get_user_meta($author_id, 'stripe_connect_id', true);
                if (!$tax_option) $tax_option = floatval(get_user_meta($author_id, 'tax_option', true));
                if (!$taxe_sejour) $taxe_sejour = intval(get_user_meta($author_id, 'taxe_calculation', true));
                if (empty($date_arrivee)) $date_arrivee = get_user_meta($author_id, 'date_arrivee', true);
                if (empty($date_depart)) $date_depart = get_user_meta($author_id, 'date_depart', true);
            }
            error_log("✅ Données utilisées depuis les métadonnées WooCommerce/user pour #$order_id");
        }
    }

    // Sécurité critique : vérifie bien la présence de tous les champs nécessaires
    if (empty($author_id) || empty($stripe_connect_id)) {
        error_log("❌ Champs obligatoires manquants (author_id/stripe_connect_id)");
        wp_send_json_error(['error' => 'Impossible de récupérer les données Stripe nécessaires à la commande.']);
    }

    // (DEBUG si besoin)
    error_log("🧾 Données utilisées pour la commande #$order_id :");
    error_log("author_id = $author_id");
    error_log("stripe_connect_id = $stripe_connect_id");
    error_log("tax_option = $tax_option");
    error_log("taxe_sejour = $taxe_sejour");
    error_log("date_arrivee = $date_arrivee");
    error_log("date_depart = $date_depart");

    $compteProprietaire = $stripe_connect_id;

    // ⚠️ Vérifie bien le nom de la méta pour montant_ht : _montant_ht ou montant_ht
    
    $montant_ttc = intval(round($order->get_total() * 100));
    $taxe_sejour = intval($stripe_data['taxe_sejour']);
    $montant_ht  = $montant_ttc - $taxe_sejour;


    if (!$compteProprietaire || $montant_ht <= 0 || $montant_ttc <= 0) {
        error_log("❌ Paramètres de paiement invalides");
        wp_send_json_error(['error' => 'Paramètres de paiement invalides.']);
    }


    $first_name = $order->get_billing_first_name();
    $last_name  = $order->get_billing_last_name();

    $compteFiscale     = defined( 'STRIPE_FISCAL_ACCOUNT' )    ? STRIPE_FISCAL_ACCOUNT    : 'acct_fiscale';
    $comptePlateforme  = defined( 'STRIPE_PLATFORM_ACCOUNT' ) ? STRIPE_PLATFORM_ACCOUNT : 'acct_plateforme';

    $halfSteps = intval( round( $tax_option * 2 ) );
    if ( $halfSteps < 0 || $halfSteps > 6 ) {
        http_response_code( 400 );
        echo json_encode( [ 'error' => 'tax_option invalide : doit être un multiple de 0.5 entre 0 et 3.' ] );
        exit;
    }
    $tax_option       = $halfSteps / 2.0;
    $proprioPct       = max( 85, min( 85 + $tax_option, 88 ) );
    $plateformePct    = max( 12, min( 100 - $proprioPct, 15 ) );
    $ratioProprio     = $proprioPct / 100.0;
    $ratioPlateforme  = $plateformePct / 100.0;
    $commissionProp   = intval( round( $montant_ht * $ratioProprio ) );
    $commissionPlat   = $montant_ht - $commissionProp;
    $sommeTransferts  = $commissionProp + $commissionPlat + $taxe_sejour;
    if ($sommeTransferts !== $montant_ttc) {
    error_log("❌ Incohérence entre transferts et montant TTC.");
    http_response_code(400);
    echo json_encode(['error' => 'Incohérence entre les montants à transférer et le TTC.']);
    exit;
    }
    // 1) Construction des paramètres — jamais de null
    $params = [
        'amount'                    => (int) $montant_ttc,   // centimes
        'currency'                  => 'eur',
        'automatic_payment_methods' => ['enabled' => true],
        'capture_method'            => 'manual',
        'statement_descriptor_suffix' => 'VACANCES',
        'description'               => "Commande #$order_id – " . ($property_name ?? ''),
        'transfer_group'            => "group_order_$order_id",
    ];

    if (!empty($customer_id))    { $params['customer']      = $customer_id; }
    if (!empty($customer_email)) { $params['receipt_email'] = $customer_email; }

    /* Métadonnées (chaîne ≠ '') */
    $params['metadata'] = array_filter([
        /* Références et fiscalité */
        'order_id'          => (string) $order_id,
        'offer_name'        => (string) ($property_name ?? ''),
        'montant_ht'        => (string) $montant_ht,
        'tax_option'        => (string) $tax_option,
        'taxe_sejour'       => (string) $taxe_sejour,
        'transfert_differe' => '1',

        /* Identité & contact client */
        'billing_first_name' => (string) ($first_name      ?? ''),
        'billing_last_name'  => (string) ($last_name       ?? ''),
        'email'              => (string) ($customer_email  ?? ''),
        'phone'              => (string) ($payer_phone     ?? ''),

        /* Séjour */
        'check_in'  => (string) ($date_arrivee ?? ''),
        'check_out' => (string) ($date_depart  ?? ''),

        /* Adresse à plat (toujours présentes, même si vides) */
        'shipping_line1'        => (string) ($billing_address1   ?? ''),
        'shipping_line2'        => (string) ($billing_address2   ?? ''),
        'shipping_postal_code'  => (string) ($billing_postcode   ?? ''),
        'shipping_city'         => (string) ($billing_city       ?? ''),
        'shipping_country'      => (string) ($billing_country    ?? ''),
        ], fn ($v) => $v !== '');          // retire les vides

    
    try {
        /* 2) Création du PaymentIntent */
        $paymentIntent = \Stripe\PaymentIntent::create($params);
        $piId = $paymentIntent->id;

        // --- AJOUT : Création du fichier pi_ dans /stripe/transfers/done ---
        $doneDir = $_SERVER['DOCUMENT_ROOT'] . '/stripe/transfers/done';
        if (!is_dir($doneDir)) {
            mkdir($doneDir, 0755, true);
        }
        $lock = $doneDir . "/{$piId}.lock";
        if (file_exists($lock)) {
            http_response_code(200);
            echo json_encode(['status' => 'info', 'message' => 'Déjà traité']);
            exit;
        }
        // Création du lock immédiatement
        touch($lock);

        // On ne fait la suite qu’une seule fois
        $transfers = [
            [
                'amount'         => (int) $taxe_sejour,
                'destination'    => $compteFiscale,
                'transfer_group' => "group_order_$order_id",
                'type'           => 'taxe_sejour',
            ],
            [
                'amount'         => (int) $commissionProp,
                'destination'    => $compteProprietaire,
                'transfer_group' => "group_order_$order_id",
                'type'           => 'proprietaire',
            ],
            [
                'amount'         => (int) $commissionPlat,
                'destination'    => $comptePlateforme,
                'transfer_group' => "group_order_$order_id",
                'type'           => 'plateforme',
            ],
        ];

        /* 4) Sauvegarde JSON pour exécution / audit */
        $transfersDir = $_SERVER['DOCUMENT_ROOT'] . '/stripe/transfers';
        if (!is_dir($transfersDir)) {
            mkdir($transfersDir, 0755, true);
        }
        $path = "$transfersDir/group_order_{$order_id}.json";
        file_put_contents($path, json_encode($transfers, JSON_PRETTY_PRINT));
        error_log("✅ Fichier transferts mis à jour : $path");

        // ---- ENREGISTREMENT DU PI ---
        $pi_file = $doneDir . "/pi_{$piId}.json";
        file_put_contents($pi_file, json_encode([
            'order_id'       => $order_id,
            'payment_intent' => $piId,
            'created'        => time(),
            'status'         => 'pi_confirm',
            'amount'         => $paymentIntent->amount,
            'currency'       => $paymentIntent->currency,
            'transfers'      => $transfers,
        ], JSON_PRETTY_PRINT));

        /* 5) Réponse au front */
        echo json_encode([
            'clientSecret' => $paymentIntent->client_secret,
            'transfers'    => $transfers,           // à titre informatif
            'message'      => '✅ Paiement enregistré, transferts programmés.',
        ]);

    } catch (\Stripe\Exception\ApiErrorException $e) {
        http_response_code(400);
        echo json_encode(['error' => $e->getMessage()]);
    }

exit;

}
