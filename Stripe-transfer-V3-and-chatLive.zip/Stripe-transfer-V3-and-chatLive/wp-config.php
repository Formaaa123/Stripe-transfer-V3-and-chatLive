<?php
define( 'WP_CACHE', false ); // Added by WP Rocket


/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';

define('COMETCHAT_APP_ID', 'TOKEN');
define('COMETCHAT_API_KEY', 'TOKEN');
define('COMETCHAT_REGION', 'eu');
define('COMETCHAT_WIDGET_ID', 'TOKEN');
define('COMETCHAT_TOKEN_EXPIRY', 86400);

define('STRIPE_SECRET_KEY', 'TOKEN');
define('STRIPE_WEBHOOK_SECRET1', 'TOKEN');
define('STRIPE_WEBHOOK_SECRET', 'TOKEN');

define('STRIPE_PLATFORM_ACCOUNT', 'acct_TOKEN');
define('STRIPE_FISCAL_ACCOUNT', 'acct_TOKEN'); 

define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);   
